# include <Stdio.h>
/*
* Navkaran Singh 
* 3119008
* Assignment 1
* Question 2
*/
int main(){
	printf("   *   \n  *|*  \n *(|)* \n*******");
	return 0;
}