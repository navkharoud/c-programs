# include <Stdio.h>
/*
* Navkaran Singh 
* 3119008
* Assignment 1
* Question 1
*/
int main(){
	printf("Beware the Jabberwock, my son \n");
	printf(" The jaws that bite, the claws that catch! \n");
	printf("Beware the Jubjub bird, and shun \n");
	printf(" The frumious Bandersnatch! \n\n");
	printf("\t-- Lewis Carroll");
	return 0;
}